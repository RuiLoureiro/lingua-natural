#!/bin/bash

python3 mp2.py $1 $2

# ./run.sh corpora/QuestoesConhecidas.txt corpora/NovasQuestoes.txt > ResultadosDes.txt